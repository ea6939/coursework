% Gain
G = .5;

numerator = [1 0];
denominator = [1 G];
H = freqz(numerator, denominator);
h = abs(ifft(H));
plot(h);