image = cast(imread('claire.tiff'), 'double');

y = zeros(576,720);
T = 50;


vertical_sobel_filter = fspecial('sobel');
horizontal_sobel_filter = transpose(vertical_sobel_filter);

edges = conv2(image, vertical_sobel_filter);%vertical_sobel_filter);

for n1 = 1:1:576
    for n2 = 1:1:720
        if(edges(n1,n2) > T)
            y(n1,n2) = 1;
        else y(n1,n2) = 0;
        end
    end
end


imagesc(y);
colormap(gray);