checkers = imread('checkerboard.tiff');

short_term_checkers = STFT(checkers,4);